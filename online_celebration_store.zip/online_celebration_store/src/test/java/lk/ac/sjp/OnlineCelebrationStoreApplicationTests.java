package lk.ac.sjp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineCelebrationStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
