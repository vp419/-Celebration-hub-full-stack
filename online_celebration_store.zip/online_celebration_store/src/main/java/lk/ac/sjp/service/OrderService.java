package lk.ac.sjp.service;

import lk.ac.sjp.model.Order;
import lk.ac.sjp.model.OrderItem;
import lk.ac.sjp.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    // Process a new checkout
    public Order createOrder(Order order) {
        
        // 1. Generate a random, professional-looking order tracking number (e.g., ORD-A1B2C3D4)
        String trackingNumber = "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        order.setOrderTrackingNumber(trackingNumber);
        
        // 2. Make sure every item in the cart knows which Order it belongs to
        if (order.getItems() != null) {
            for (OrderItem item : order.getItems()) {
                item.setOrder(order);
            }
        }
        
        // 3. Save the Order (Because of CascadeType.ALL in your Entity, this saves the OrderItems too!)
        return orderRepository.save(order);
    }

    // Fetch all orders (This will be very useful if you build an Admin Dashboard later)
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
}