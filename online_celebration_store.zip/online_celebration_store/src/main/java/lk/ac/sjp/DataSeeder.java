package lk.ac.sjp;

import lk.ac.sjp.model.Product;
import lk.ac.sjp.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner initDatabase(ProductRepository repository) {
        return args -> {
            // Only add data if the database is empty
            if (repository.count() == 0) {
                Product p1 = new Product();
                p1.setName("Gold Balloon Arch Kit");
                p1.setCategory("Decor");
                p1.setPrice(29.99);
                p1.setOriginalPrice(39.99);
                p1.setBadge("Bestseller");
                p1.setImage("https://images.unsplash.com/photo-1530103862676-de8892b12f71?q=80&w=400&auto=format&fit=crop");
                p1.setRating(5);
                p1.setReviews(128);
                repository.save(p1);

                Product p2 = new Product();
                p2.setName("Premium Party Gift Box");
                p2.setCategory("Gifts");
                p2.setPrice(45.00);
                p2.setOriginalPrice(null);
                p2.setBadge("New");
                p2.setImage("https://images.unsplash.com/photo-1549465220-1a8b9238cd48?q=80&w=400&auto=format&fit=crop");
                p2.setRating(4);
                p2.setReviews(56);
                repository.save(p2);
                
                Product p3 = new Product();
                p3.setName("Neon 'Let's Party' Sign");
                p3.setCategory("Decor");
                p3.setPrice(89.99);
                p3.setOriginalPrice(110.00);
                p3.setBadge("Sale");
                p3.setImage("https://images.unsplash.com/photo-1563298723-dcfebaa392e3?q=80&w=400&auto=format&fit=crop");
                p3.setRating(5);
                p3.setReviews(204);
                repository.save(p3);
                
                System.out.println("Sample products loaded into the database!");
            }
        };
    }
}