package lk.ac.sjp.controller;

import lk.ac.sjp.model.Order;
import lk.ac.sjp.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "*") // Allows your React app to talk to this endpoint securely
public class OrderController {

    @Autowired
    private OrderService orderService;

    // POST: Create a new order (Triggered by the React Checkout button)
    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        Order savedOrder = orderService.createOrder(order);
        // Returns the saved order (with its new ID and Tracking Number) back to React
        return new ResponseEntity<>(savedOrder, HttpStatus.CREATED);
    }

    // GET: Fetch all orders (Perfect for an Admin Dashboard later)
    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }
}