package lk.ac.sjp.repository;

import lk.ac.sjp.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    
    // Spring Boot will automatically write the SQL to find products by their category!
    List<Product> findByCategory(String category);
}