package lk.ac.sjp.repository;

import lk.ac.sjp.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    // JpaRepository automatically provides the save() method we need for checkout!
}