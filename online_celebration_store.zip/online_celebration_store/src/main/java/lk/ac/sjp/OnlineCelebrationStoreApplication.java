package lk.ac.sjp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineCelebrationStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineCelebrationStoreApplication.class, args);
	}

}
